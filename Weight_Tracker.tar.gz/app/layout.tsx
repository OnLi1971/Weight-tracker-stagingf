import type { Metadata } from 'next';
import { MacalySandboxBridge } from '../.sandbox/sandbox-bridge';
import { Inter } from 'next/font/google';
import './globals.css';
import { Toaster } from '@/components/ui/sonner';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Mounjaro Tracker',
  description: 'Sledování hmotnosti a dávek Mounjaro pro skupiny',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="cs">
      <MacalySandboxBridge><body className={inter.className}>
        {children}
        <Toaster />
      </body></MacalySandboxBridge>
    </html>
  );
}